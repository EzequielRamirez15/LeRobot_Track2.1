import mujoco
import mujoco.viewer
import numpy as np
import time
import os

model_path = os.path.join(os.path.dirname(__file__), "../mujoco_models/two_robot_scene_with_elbow.xml")
model = mujoco.MjModel.from_xml_path(model_path)
data = mujoco.MjData(model)
viewer = mujoco.viewer.launch_passive(model, data)

step = 0
cycle = 0
max_cycles = 3

gripper_left = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, "joint_gripper_left")
gripper_right = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, "joint_gripper_right")
cubo_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "object")
cubo_pos = data.xpos[cubo_id]

while viewer.is_running() and cycle < max_cycles:
    step += 1
    if step < 300:
        data.ctrl[1] = 0.8
    elif step < 600:
        data.ctrl[0] = 0.5
    elif step < 900:
        data.ctrl[2] = 1.0
    elif step < 1200:
        data.ctrl[2] = -1.0
    elif step < 1500:
        data.ctrl[1] = -0.8
    else:
        data.ctrl[:3] = 0.0

    if step < 1000:
        data.ctrl[3] = -0.04
        data.ctrl[4] = 0.04
    elif step >= 1400:
        data.ctrl[3] = 0.04
        data.ctrl[4] = -0.04

    cubo_pos = data.xpos[cubo_id]
    print(f"[{step}] Posición del cubo: x={cubo_pos[0]:.3f}, y={cubo_pos[1]:.3f}, z={cubo_pos[2]:.3f}")

    if step > 1600:
        step = 0
        cycle += 1

    mujoco.mj_step(model, data)
    viewer.sync()
    time.sleep(0.01)

print("✅ Simulación con pinzas finalizada.")
viewer.close()
